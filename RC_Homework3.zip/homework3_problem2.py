temp = 90
while temp > 75:
  print("The temperature is", temp, "- crank the AC!")
  temp -= 3
else:
  print(temp, ".", " Ahh, that's better", sep='')
