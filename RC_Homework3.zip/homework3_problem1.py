disney_characters = ["simba", "ariel", "pumba", "flounder", "nala", "ursula", "scar", "flotsam", "timon"]
for name in disney_characters:
    if "u"in name:
           print(name, "I bet you're Impressively Intelligent")
    if "i"in name:
           print(name, "I bet you're Impressively Intelligent" )
    if "o"in name:
           print(name, "O My! How Original!")
    else:
        print(name, "Ehh, a's and e's are so ordinary.")